require('dotenv').config()
const express = require('express');
//Rest api module
const fs = require('fs');
//const index = fs.readFileSync()
const data = JSON.parse(fs.readFileSync('data.json', 'utf-8'));
const Products = data.products;

// const stripe = require('stripe')('sk_test_51Mix02SImlbs6lSYBt2B1OYwdWc9te2H0njDJ01ioVxbhdAWaIYumQLu4OUTWepHZLjT4vjU4pu3teJ8WixgfGmp00noEmPipq');
const bodyParser = require('body-parser');
const cors = require('cors')
const Stripe = require('stripe');
// const stripe = Stripe('sk_test_51Mix02SImlbs6lSYBt2B1OYwdWc9te2H0njDJ01ioVxbhdAWaIYumQLu4OUTWepHZLjT4vjU4pu3teJ8WixgfGmp00noEmPipq')
const stripe = Stripe(process.env.STRIPE_SECRET_KEY)
// console.log(process.env.STRIPE_SECRET_KEY)
const app = express();
const PORT = 4002

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json())
app.use(cors())
app.use(bodyParser.json())

app.get('/demo', (req, res) => {
  res.send('Hello get data successfully')
})

///REST APIS


//API-ROOT, BASE URL

// Read GET /Products
app.get('/Products', (req, res) => {
  res.json(Products)
})

// Read GET /Products:id
app.get('/Products/:id', (req, res) => {
  const id = +req.params.id;
  const product = Products.find(p => p.id == id)
  res.json(product)
})

// Create Post /Product
app.post('/Products', (req, res) => {
  console.log(req.body);
  Products.push(req.body)
  res.json(req.body)
})

// Update PUT /Products /:id
app.put('/Products/:id', (req, res) => {
  const id = +req.params.id;
  const ProductIndex = Products.findIndex(p => p.id === id)
  Products.splice(ProductIndex, 1, { ...req.body, id: id })
  res.status(201).json()
})

// Update PATCH /Products /:id
app.patch('/Products/:id', (req, res) => {
  const id = +req.params.id;
  const ProductIndex = Products.findIndex(p => p.id === id)
  const product = Products[ProductIndex]
  //console.log(product)
  Products.splice(ProductIndex, 1, { ...product, ...req.body })
  //console.log(product)
  res.status(201).json()
})

// Delete DELETE /Products /:id
app.delete('/Products/:id', (req, res) => {
  const id = +req.params.id;
  const ProductIndex = Products.findIndex(p => p.id === id)
  const product = Products[ProductIndex]
  Products.splice(ProductIndex, 1)
  res.status(201).json(product)
})


//Middleware
// app.use((req,res,next) => {
//   console.log(req.method, req.ip, req.hostname, Date(), req.get('User-Agent'))
//   next()
// })

// Api - Endpoint
// app.get('/',(req,res) => {
//   res.json({type: 'GET'})
// })
// app.put('/',(req,res) => {
//   res.json({type: 'PUT'})
// })
// app.post('/',(req,res) => {
//   res.json({type: 'POST'})
// })
// app.delete('/',(req,res) => {
//   res.json({type: 'DELETE'})
// })
// app.patch('/',(req,res) => {
//   res.json({type: 'PATCH'})
// })

// app.post('/payment-sheet', async (req, res) => {

//   const { customerId, amount, email, name, cardNumber, cardExpMonth, cardExpYear, cardCvc } = req.body;
//   try {
//     const customer = await stripe.customers.create({
//       email: "sumit@gmail.com",
//       name: "sumit"
//     });

//     console.log('Customer created:', customer);
//     const ephemeralKey = await stripe.ephemeralKeys.create(
//       {customer: customer.id},
//       {apiVersion: '2022-11-15'}
//     );
//     const paymentIntent = await stripe.paymentIntents.create({
//       amount: amount,
//       currency: 'inr',
//       customer: customerId,
//     });

//     const paymentMethod = await stripe.paymentMethods.create({
//       type: 'card',
//       card: {
//         number: cardNumber,
//         exp_month: cardExpMonth,
//         exp_year: cardExpYear,
//         cvc: cardCvc,
//       },
//     });
//     const paymentIntentConfirmation = await stripe.paymentIntents.confirm(paymentIntent.id, {
//       payment_method: paymentMethod.id,
//     });
//     console.log('Payment intent confirmation:', paymentIntentConfirmation);
//     res.json({
//       paymentIntent: paymentIntentConfirmation.client_secret,
//       customer: customer.id,
//       ephemeralKey: ephemeralKey.secret
//       //publishableKey: process.env.STRIPE_PUBLISHABLE_KEY,
//     });
//   } catch (error) {
//     console.log(error);
//     res.status(500).json({message: 'Internal server error'})
//   }
// });










app.post("/pay", async (req, res) => {
  try {
    //const { name } = req.body;
    //if (!name) return res.status(400).json({ message: "Please enter a name" });
    const customerId = await stripe.customers.create();
    const customers = await stripe.customers.list();
    const customer = customers.data[0];

    if (!customer) {
      return res.send({
        error: 'you have no customer created'
      })
    }



    const paymentIntent = await stripe.paymentIntents.create({
      amount: 2000,
      currency: "INR",
      payment_method_types: ["card"],
      customer: customerId.id,
      //receipt_email: customer.email, 
      //metadata: { name },
    });
    // console.log(customers);
    //console.log(receipt_email, "rahula@gmail.com")
    const clientSecret = paymentIntent.client_secret;
    res.json({ message: "Payment initiated", clientSecret });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Internal server error" });
  }
});

app.post("/stripe", async (req, res) => {
  const sig = req.headers["stripe-signature"];
  let event;
  try {
    event = await stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: err.message });
  }

  // Event when a payment is initiated
  if (event.type === "payment_intent.created") {
    console.log(`${event.data.object.metadata.name} initated payment!`);
  }
  // Event when a payment is succeeded
  if (event.type === "payment_intent.succeeded") {
    console.log(`${event.data.object.metadata.name} succeeded payment!`);
    // fulfilment
  }
  res.json({ ok: true });
});




app.listen(PORT, () => console.log(`Running on http://localhost:${PORT}`))


require('dotenv').config()
const express = require('express');
// const stripe = require('stripe')('sk_test_51Mix02SImlbs6lSYBt2B1OYwdWc9te2H0njDJ01ioVxbhdAWaIYumQLu4OUTWepHZLjT4vjU4pu3teJ8WixgfGmp00noEmPipq');
//const bodyParser = require('body-parser');
const cors = require('cors')
const Stripe = require('stripe');
// const stripe = Stripe('sk_test_51Mix02SImlbs6lSYBt2B1OYwdWc9te2H0njDJ01ioVxbhdAWaIYumQLu4OUTWepHZLjT4vjU4pu3teJ8WixgfGmp00noEmPipq')
const stripe = Stripe(process.env.STRIPE_SECRET_KEY)
// console.log(process.env.STRIPE_SECRET_KEY)
const app = express();
const PORT = 4002

//app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json())
app.use(cors())
//app.use(bodyParser.json())

app.get('/', (req, res) => {
  res.send('Hello get data successfully')
})




// Create a customer
// app.post('/create-customer', async (req, res) => {
//   try {
//     const { email, name, card } = req.body;

//     // Generate a token from the card details
//     const token = await stripe.tokens.create({
//       card: {
//         number: card.number,
//         exp_month: card.exp_month,
//         exp_year: card.exp_year,
//         cvc: card.cvc
//       }
//     });

//     // Create the customer with the generated token
//     const customer = await stripe.customers.create({
//       email: email,
//       name: name,
//       source: token.id
//     });

//     console.log('Customer created:', customer);
//     res.json({ customer: customer });
//   } catch (error) {
//     console.log('Error creating customer:', error);
//     res.status(500).json({ error: error.message });
//   }
// });

// // Retrieve a customer
// app.get('/retrieve-customer/:customerId', async (req, res) => {
//   try {
//     const customerId = req.params.customerId;
//     const customer = await stripe.customers.retrieve(customerId);
//     console.log('Customer retrieved:', customer);
//     res.json({ customer: customer });
//   } catch (error) {
//     console.log('Error retrieving customer:', error);
//     res.status(500).json({ error: error.message });
//   }
// });

// // Add a card to a customer
// app.post('/add-card-to-customer', async (req, res) => {
//   try {
//     const { customerId, sourceToken } = req.body;
//     const source = await stripe.customers.createSource(customerId, { source: sourceToken });
//     console.log('Card added to customer:', source);
//     res.json({ source: source });
//   } catch (error) {
//     console.log('Error adding card to customer:', error);
//     res.status(500).json({ error: error.message });
//   }
// });

// // Charge a customer
// app.post('/charge-customer', async (req, res) => {
//   try {
//     const { customerId, amount } = req.body;
//     const paymentIntent = await stripe.paymentIntents.create({
//       amount: amount,
//       currency: 'inr',
//       customer: customerId,
//     });
//     const paymentMethod = await stripe.paymentMethods.list({
//       customer: customerId,
//       type: 'card',
//     });
//     const paymentMethodId = paymentMethod.data[0].id;
//     const paymentIntentConfirmation = await stripe.paymentIntents.confirm(paymentIntent.id, {
//       payment_method: paymentMethodId,
//     });
//     console.log('Payment intent confirmation:', paymentIntentConfirmation);
//     res.json({ paymentIntentConfirmation: paymentIntentConfirmation });
//   } catch (error) {
//     console.log('Error charging customer:', error);
//     res.status(500).json({ error: error.message });
//   }
// });

// Open payment sheet
// app.post('/payment-sheet', async (req, res) => {
//   try {
//     const { customerId, amount } = req.body;
//     const paymentIntent = await stripe.paymentIntents.create({
//       amount: amount,
//       currency: 'inr',
//       customer: customerId,
//     });
//     const paymentSheet = await stripe.paymentSheets.create({
//       payment_intent: paymentIntent.id,
//       customer: customerId,
//       //success_url: 'https://example.com/success',
//       //cancel_url: 'https://example.com/cancel',
//     });
//     console.log('Payment sheet:', paymentSheet);
//     res.json({ paymentSheet: paymentSheet });
//   } catch (error) {
//     console.log('Error opening payment sheet:', error);
//     res.status(500).json({ error: error.message });
//   }
// });









//success code
app.post('/payment-sheet', async (req, res) => {
  try {
    async function createCustomer(email, name) {
      try {
        const customer = await stripe.customers.create({
          email: email,
          name: name
        });
    
        console.log('Customer created:', customer);
    
        return customer;
      } catch (error) {
        console.log('Error creating customer:', error);
        throw error;
      }
    }
    // createCustomer('pawantest@gmail.com', 'pawanv');
    async function retrieveCustomer(customerId) {
      try {
        const customer = await stripe.customers.retrieve(customerId);
    
        console.log('Customer retrieved:', customer);
    
        return customer;
      } catch (error) {
        console.log('Error retrieving customer:', error);
        throw error;
      }
    }
    retrieveCustomer('cus_NiCNGFx41MMHnM');

    async function createToken(cardNumber, cardExpMonth, cardExpYear, cardCvc) {
      try {
        const token = await stripe.tokens.create({
          card: {
            number: cardNumber,
            exp_month: cardExpMonth,
            exp_year: cardExpYear,
            cvc: cardCvc
          }
        });
        console.log(token); // Log the token object to console
        return token;
      } catch (error) {
        console.log(error);
      }
    }
    //createToken('4242424242424242', '12', '2024', '123')

   // createToken('4242424242424242',)

    const chargeCustomer = async (customerId, amount) => {
      try {
        const paymentIntent = await stripe.paymentIntents.create({
          amount: amount,
          currency: 'inr',
          customer: customerId,
        });
        const paymentMethod = await stripe.paymentMethods.list({
          customer: customerId,
          type: 'card',
        });
        const paymentMethodId = paymentMethod.data[0].id;
        const paymentIntentConfirmation = await stripe.paymentIntents.confirm(paymentIntent.id, {
          payment_method: paymentMethodId,
        });
        console.log('Payment intent confirmation:', paymentIntentConfirmation);
      } catch (error) {
        console.log('Error:', error);
      }
    }
    //createToken('4242424242424242', '12', '2024', '123');
    //chargeCustomer('cus_NiANdc7GUjhfKc', 5000);
    async function addCardToCustomer(customerId, sourceToken) {
      try {
        const source = await stripe.customers.createSource(customerId, { source: sourceToken });
        console.log(source); // Log the source object to console
        return source;
      } catch (error) {
        console.log(error);
      }
    }

  } catch (error) {
    console.log(error);
    res.send(500).json({message: 'Internal server error'})
  }
})



app.listen(PORT, () => console.log(`Running on http://localhost:${PORT}`))

